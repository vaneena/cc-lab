﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_mid_qs_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void generateButton_Click(object sender, EventArgs e)
        {
            // Get user input
            string registration = registrationTextBox.Text;
            string firstName = firstNameTextBox.Text;
            string lastName = lastNameTextBox.Text;
            string favoriteMovie = favoriteMovieTextBox.Text;

            // Validate input
            if (registration.Length < 2 || firstName.Length < 2 || lastName.Length < 2 || favoriteMovie.Length < 2)
            {
                MessageBox.Show("Please enter valid information for all fields.");
                return;
            }

            // Generate password components
            string regDigits = registration.Substring(0, 2);
            char firstLetter = firstName[1];
            char lastLetter = lastName[1];
            string movieChars = favoriteMovie.Substring(0, 2);
            string specialChars = "!@$%^&*()-+=";

            // Construct the password
            string password = $"{regDigits}{firstLetter}{lastLetter}{movieChars}";

            // Add special characters and adjust to required length
            var random = new Random();
            while (password.Length < 14)
            {
                char specialChar = specialChars[random.Next(specialChars.Length)];
                if (specialChar != '#')
                {
                    password += specialChar;
                }
            }

            // Display the generated password
            passwordLabel.Text = $"Generated Password: {password}";
        }
    }
}
    
